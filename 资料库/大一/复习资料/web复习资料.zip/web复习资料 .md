 一、常用html标记  
1. head标记
		包含标题标记、脚本标记、风格标记、meta标记等。
2. body标记
		包含的标记是显示在浏览器内容窗口中的，有：
3. 标题标记 h1~h6
4. 段落标记 p
		
		<p>你好</p>

5. 文本修饰标记：  
  例如：
  
		<b>  粗体字</b>  
		<i>  斜体字</i>  
		<u>  下划线</u>  
		<del>  删除线</del>  
		<sup>  2</sup>  
		<sub>  2</sub>  
		<strong>川闲居赠裴秀才迪</strong>  
		<em>   王维</em>  
		<small>  软件工程专业！</small>  
		<big>  软件工程专业！</big>  
		
6. 列表标记  
	1）有序列表  
		
		<ol type="">  
			<li value="">软件工程</lili>  
			<li value="">临床</li >  
			<li value="">临床</li >     
		</ol>  
		
	2）无序列表  
  
		<ul type="">  
			<li value=""></li>  
		</ul  

7. 超链接标记a  
	
		<a href="" target="" title="">红色超链接</a>  
	
8. 图像标记 img  
		
		<img src="img/pic.png" width="" height="" />  
		
	宽高用像素表示。  
9.  视频标记 video  
		
		<video src="" width="" height=""></video>  
		
10. div标记-没有特定含义，通过用来做元素的容器,结合盒模型进行页面布局。  
		
		<div id="" class="" style="">  
			内容  
		</div>  
		
11. table、tr、td、th标记  

		<table>
			<tr>
				<th></th>
			</tr>
			<tr>
				<td></td>
			</tr>
		</table>  
	
12. form表单标记，input标记  ，textarea标记  ，select标记，option标记  
		
```html
<form action=" " name=" " onsubmit="">
	<label for="sname">账号：</label><input type="text" id="sname" value="" /><br />
	<label for="pwd">密码：</label><input type="password" id="pwd" value=""/><br />
	
	<input type="button" value="提交" />
	<input type="reset" name="" value="重置">
</form>
```
    
例如：写一段html代码，里面包含一张图片和一个水平列表。

		<div class="top">
			<div class="picbox">
				<img src="img/newspic1.jpg" alt="">
			</div>
			<div class="nav_ul">
				<ul>
					<li>首页</li>
					<li>文化</li>
					<li>历史</li>
				</ul>
			</div>		    
		</div>   
		
例如：使用div标签写页面框架，将页面分成：上header、中content、下footer三个区。  
	其中header区包含top区和菜单menu区，content区包含main区和sidebar区，其中main区和sidebar区水平排列。  
       
		<div class="header">
            <div class="top">       </div>
            <div class="menu">      </div>
        </div>
        <div class="content">
            <div class="main"> </div>
            <div class="sidebar"> </div>
        </div>
        <div class="footer">     </div>
	
二、  html元素常用的内嵌属性  

    属性：用来说明元素的特征、状态、外观、来源等  
	
	
1.    align属性：align="center|right|left|justify" 对齐方式
2.    width和height属性：用像素表示。例如：width="100px"
3.    value属性：值，元素得到的值放在value属性。例如：option、input等表单元素
4.    src属性：文件来源，例如img，video
5.    href属性：超文本的来源，例如a链接
6.    name属性：表示元素的名称
7.    id属性：元素的id标记，可通过dom方法查找到元素，可为该id设置css属性
8.    class属性：元素的类名称（引用所使用的类名）
9.    style属性：大部分元素都具有，用来书写内联css样式

	  
三、CSS属性
    css将元素的外观和元素本身分开，使代码简洁，并可以控制多个页面，减少页面重复建设
CSS属性分类如下：
1. 字体属性
     字体属性	    属性值	描述
	1. font-size	    px，em，百分比等	字体大小
	2. font-style	    normal | italic | oblique	字体样式
	3. font-family	    黑体,隶书,楷体_gb2312,…….	字体名称
	4. font-variant	normal | small-caps	字体变体
	5. font-weight	    normal | bold | bolder | lighter |100|200|…|900	字体加粗  

	例如：设置p段落的样式为，大小18号，倾斜，字体加粗  
	
		p{  
			font-size:18px;  
			font-style: italic;  
			font-weight: bold;
		}  
	
  2. 文本属性
    文本属性	属性值	描述  
    1. color	    颜色值	设置文本的颜色  
	2. letter-spacing	normal |长度	设置字符间距  
	3. line-height	    normal |长度	设置行高。  
	4. text-align	    left | right | center |justify（两端对齐）	规定文本的水平对齐方式  
	5. vertical-align	    top| middle | bottom |..	设置元素的垂直对齐方式  
	6. text-decoration	    none | underline |overline | line-through	规定添加到文本的装饰效果。  
	7. text-indent	    长度 | 百分比	规定文本块首行的缩进。  
	8. text-transform	capitalize | uppercase | lowercase| none	控制文本的英文大小写。  
	9. word-spacing	normal |长度	设置单词间距。  
	
	例如：设info类的样式为：红色字体，字符间距10px，行高40px，文本居中，有下划线，首行缩进2字符。  
	
		.info{  
			color:red;  
			letter-spacing:10px;  
			line-height:40px;  
			text-align:center;  
			text-decoration:underline;  
			text-indent:2rem;  
		}  

3. 颜色属性  
    颜色属性	属性值	                                 描述  
    color	red、blue、yellow……                      颜色名称  
            rgb（RRR, GGG, BBB）或rgb（r%, g%, b%）   颜色分量：0~100%  
            "#RRGGBB"或者"#RGB"	                     十六进制数  
	例如：设div的前景色为浅蓝色。  
    
		div{  
			color:lightblue;  
		}  

4. 背景属性  
    背景属性			属性值				描述  
    background-color:	关键字 |  RGB值 | transparent	背景颜色  
    background-image:	url(*.jpg) | none	背景图像  
    background-attachment:	scroll | fixed	附件  
    background-repeat:	repeat | repeat-x | repeat-y |no-repeat	  
    background-position: 水平位置值  垂直位置值 	
		                【left、center、right或百分比】 【top、center、bottom或百分比 】 
    background: 颜色|背景 重复 位置 附件			复合属性    
    
	例如：设#nav的样式为：宽800px，高80px，背景色为淡蓝色  
    
		#nav{  
			width:800px; height:80px;  
			background-color:lightblue;  
		}  

5. 列表属性  
    列表属性					属性值						描述  
    list-style-type: disc |circle |square |decimal |lower-roman |upper-roman| lower-alpha|upper-alpha|none	指定列表项标记的类型  
    list-style-image: url(*.gif)|none	将图像作为指定列表项的标记  
    list-style-position: inside | outside	定位列表项标记的位置  
    List-style: 复合属性值  
	
	例如：设置ul列表无符号  
	
		ul{  
			list-style-type：none;  
		}  

6. float浮动属性  
   float：left|right|none;  
   clear：both;  
	
	例如：设置 ul列表为水平列表，列表项li宽100px，高40px，行高40px，背景色白色，字体为黑色。鼠标经过时背景变为黑色，字体变为白色。  

		ul{
			list-style-type:none;
		}
		li{
			
		}

7. display属性: 切换元素为块元素或内联元素。  
	例如：设置链接a为块元素，宽100px,高40px，背景色为白色，字体为黑色； 鼠标经过时背景为单蓝色，字体为橙色。  
	
		a{
			
		}


8. 盒模型属性：margin、padding和border  
   与postion属性和float属性相配合，可以改变元素的位置，从而实现页面布局。  
   1. margin：外边距（外边界），有1-4个参数，其中margin：0 auto，可使元素在父元素的空间中居中。  
   2. padding：内边距（内边界），有1-4个参数  
   3. border：边框（元素的边框），有1-4个参数  
   4. border-width: 边框宽度  
   5. border-style：边框样式  
   6. border-color：边框颜色  
   7. 圆角：border-radius:8px;  
   8. 边框阴影：box-shadow: 8px,8px,4px,8px, grey;  
   
例如：div包含一张图片，设置div宽为300px,高为200px，如果图片超过div的大小，则隐藏溢出部分。（小图片设置）  
	
	div{
		
	}
	
	
例如：设置top区域：左侧放图片logo，右侧放水平列表（首页，文化，历史）。  
      top区大小为宽1000px，高100px；浏览器居中（margin：0 auto）  
      logo区:宽100px，高60px，行高100px，若logo图片溢出则隐藏  
      nav_ul区：左浮动，
	  nav_ul的ul列表项 li：无列表符号，左浮动，右外边距为30px，鼠标经过时，字体变为橙色。  
	
```html
<style> 
	/* 全局置0 */
	*{margin: 0; padding: 0;border: 0;}
	.top{				
		width:1000px; height:100px;margin:20px auto;				
	}
	.picbox{
		width:200px;height:100px;
		overflow:hidden;
		float: left;
		margin-right: 30px;
	}
	.picbox img{
		width: 100%; height: 100%;
	}
	.nav_ul{
		float: left;
	}
	.top ul {
		list-style-type: none;
	}
	.nav_ul li{
		float: left;
		line-height: 100px;
		margin-right: 30px;
	}
	.nav_ul li:hover{
		color: orangered;
	}			
</style>
```

	
	
	


